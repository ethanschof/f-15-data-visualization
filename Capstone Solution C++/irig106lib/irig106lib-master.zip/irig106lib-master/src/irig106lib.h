/**
 * @file irig106lib.h
 * @author C1C Colin Seymour
 * @brief compiles all the IRIG 106 information into a single header file
 * @version 0.1
 * @date 2022-08-21
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "config.h"
#include "i106_data_stream.h"

//#include "i106_decode_16pp194.h"
//#include "i106_decode_1394.h"
#include "i106_decode_1553f1.h"

/*#include "i106_decode_analog.h"
#include "i106_decode_analogf1.h"
#include "i106_decode_arinc429.h"

#include "i106_decode_can.h"
#include "i106_decode_comp_gen_0.h"
#include "i106_decode_discrete.h"

#include "i106_decode_ethernet.h"
#include "i106_decode_events.h"
#include "i106_decode_fc.h"

#include "i106_decode_image.h"
#include "i106_decode_message.h"
#include "i106_decode_parallel.h"

#include "i106_decode_pcmf1.h"
#include "i106_decode_streaming_config.h"
#include "i106_decode_time.h"

#include "i106_decode_tmats.h"
#include "i106_decode_tmats_b.h"
#include "i106_decode_tmats_c.h"
#include "i106_decode_tmats_common.h"
#include "i106_decode_tmats_d.h"
#include "i106_decode_tmats_g.h"
#include "i106_decode_tmats_m.h"
#include "i106_decode_tmats_p.h"
#include "i106_decode_tmats_r.h"

#include "i106_decode_uart.h"
#include "i106_decode_video.h"*/

#include "i106_index.h"
#include "i106_stdint.h"
#include "i106_time.h"

#include "irig106ch10.h"
//#include "irig106cl.h"
//#include "sha-256.h"

//#include "irig106dll.def"